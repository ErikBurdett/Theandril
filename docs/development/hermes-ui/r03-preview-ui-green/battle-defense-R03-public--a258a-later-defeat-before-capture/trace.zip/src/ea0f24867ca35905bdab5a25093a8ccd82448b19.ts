import { expect, test, type Page, type Locator } from '@playwright/test';
import { createArmyFormation, deserializeGame, serializeGame, type GameState } from '@theandril/sim';
import { exportSave } from '@theandril/persistence';
import { borderBattleCampaign } from '../../packages/test-fixtures/src/combat-fixture';
import { conquestCampaign, CONQUEST_FIXTURE as C } from '../../packages/test-fixtures/src/conquest-fixture';
import { refreshAuthoredSight } from '../../packages/test-fixtures/src/authored-land';
import { closeManagement, openRealmAffairs, openSelectedOrders } from './ui-navigation';

/** Authored full-container reserve stress fixture; no naturally earned force-size claim.
 * Uses the same setup as the parent's canonical frontage regression tests. */
function reserveCampaign(siege: boolean): GameState {
  const state = siege ? conquestCampaign() : borderBattleCampaign();
  const town = state.settlements[C.settlementId]!;
  if (siege) {
    const attackers = state.armies[C.playerArmyId]!;
    attackers.formations = Array.from({ length: 12 }, (_, index) => createArmyFormation(index === 0 ? attackers.id : `army.${state.nextId++}`, 'unit.guard')).sort((a, b) => a.id < b.id ? -1 : 1);
  }
  for (let index = 0; index < 21; index++) {
    const id = !siege && index === 0 ? 'army.4' : `army.${state.nextId++}`;
    const original = state.armies['army.4'];
    state.armies[id] = { id, name: `Reserve defender ${index}`, factionId: town.factionId,
      cell: siege ? town.cell : original!.cell, movement: 0,
      formations: [{ ...createArmyFormation(id, 'unit.scout'), strength: 1, morale: 1 }] };
  }
  refreshAuthoredSight(state);
  return deserializeGame(serializeGame(state));
}
async function importAndDeclare(page: Page, game: GameState) {
  await page.goto('/');
  await page.locator('input[type=file]').setInputFiles({ name: 'reserve-contingent.theandril', mimeType: 'application/gzip', buffer: Buffer.from(await exportSave(serializeGame(game))) });
  await expect(page.getByTestId('feedback')).toContainText('Imported campaign');
  await openRealmAffairs(page);
  await page.getByRole('button', { name: 'Declare war on Reedbound Council', exact: true }).click();
  await openSelectedOrders(page);
}
async function assertQuote(panel: Locator, quote: { engagedFormations: number; engagedStrength: number; reserveFormations: number; reserveStrength: number }) {
  await expect(panel).toContainText(`Committed defense: ${quote.engagedFormations} formations · ${quote.engagedStrength} strength`);
  await expect(panel).toContainText(`Reserves: ${quote.reserveFormations} formation · ${quote.reserveStrength} strength`);
  await expect(panel).toContainText('Reserves defend in later engagements');
}

test('R03 public attack previews the canonical contingent and leaves its reserve on the map', async ({ page }, info) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  await importAndDeclare(page, reserveCampaign(false));
  const target = page.locator('.attack-target').filter({ has: page.getByRole('button', { name: 'Attack Reserve defender 0 (army.4)', exact: true }) });
  const before = await page.evaluate(() => { const api = window.__THEANDRIL__!, view = api.getSummary()!; return { hash: api.getStateHash(), army: view.ownArmies.find(army => army.id === 'army.2')!, target: view.armies.find(army => army.id === 'army.4')! }; });
  expect(before.target.battleDefense).toBeDefined();
  await assertQuote(target.getByTestId('battle-defense-preview'), before.target.battleDefense!);
  await target.screenshot({ path: info.outputPath('field-defense-desktop.png') });
  expect(await page.evaluate(() => window.__THEANDRIL__!.getStateHash())).toBe(before.hash);
  await target.getByRole('button', { name: 'Attack Reserve defender 0 (army.4)', exact: true }).click();
  await expect(page.getByTestId('battle-panel')).toBeVisible();
  expect(await page.evaluate(() => window.__THEANDRIL__!.getSummary()!.battle!.combat.defender.length)).toBe(before.target.battleDefense!.engagedFormations);
  await page.getByRole('button', { name: 'Auto-resolve battle', exact: true }).click();
  await expect(page.getByTestId('battle-panel')).toHaveCount(0);
  const after = await page.evaluate(() => window.__THEANDRIL__!.getSummary()!);
  expect(after.ownArmies.find(army => army.id === before.army.id)!.cell).toBe(before.army.cell);
  expect(after.armies.filter(army => army.cell === before.target.cell && army.factionId === before.target.factionId)).toHaveLength(1);
  await info.attach('field-defense', { body: JSON.stringify({ before, afterArmies: after.armies, errors }, null, 2), contentType: 'application/json' });
  expect(errors).toEqual([]);
});

test('R03 public siege shows reserves at 390px and requires their later defeat before capture', async ({ page }, info) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  await importAndDeclare(page, reserveCampaign(true));
  await page.getByRole('button', { name: 'Besiege Reedwatch', exact: true }).click();
  for (let turn = 2; turn <= 4; turn++) {
    await closeManagement(page);
    await page.getByRole('button', { name: 'End turn', exact: true }).click();
    await expect(page.getByTestId('turn-counter')).toHaveText(`Turn ${turn}`);
  }
  await openSelectedOrders(page); await page.setViewportSize({ width: 390, height: 844 });
  const card = page.getByTestId(`siege-${C.settlementId}`);
  const before = await page.evaluate(() => ({ hash: window.__THEANDRIL__!.getStateHash(), siege: window.__THEANDRIL__!.getSummary()!.sieges[0]! }));
  expect(before.siege.battleDefense?.reserveFormations).toBe(1);
  await assertQuote(card.getByTestId('battle-defense-preview'), before.siege.battleDefense!);
  await card.screenshot({ path: info.outputPath('siege-defense-390.png') });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(await page.evaluate(() => window.__THEANDRIL__!.getStateHash())).toBe(before.hash);
  await page.getByRole('button', { name: 'Assault Reedwatch', exact: true }).click();
  await expect(page.getByTestId('battle-panel')).toBeVisible();
  await page.getByRole('button', { name: 'Auto-resolve battle', exact: true }).click();
  await expect(page.getByTestId('battle-panel')).toHaveCount(0);
  await expect(page.getByTestId('capture-panel')).toHaveCount(0);
  const contested = await page.evaluate(() => window.__THEANDRIL__!.getSummary()!);
  expect(contested.sieges).toHaveLength(1); expect(contested.pendingCapture).toBeNull();
  await closeManagement(page);
  await page.getByRole('button', { name: 'End turn', exact: true }).click();
  await expect(page.getByTestId('turn-counter')).toHaveText('Turn 5');
  await openSelectedOrders(page);
  await expect(card.getByTestId('battle-defense-preview')).toHaveCount(0);
  await page.getByRole('button', { name: 'Assault Reedwatch', exact: true }).click();
  await expect(page.getByTestId('battle-panel')).toBeVisible();
  await page.getByRole('button', { name: 'Auto-resolve battle', exact: true }).click();
  await expect(page.getByTestId('capture-panel')).toBeVisible();
  await page.getByRole('button', { name: 'Occupy settlement', exact: true }).click();
  await expect(page.getByTestId('capture-panel')).toHaveCount(0);
  expect(await page.evaluate(id => window.__THEANDRIL__!.getSummary()!.ownSettlements.some(town => town.id === id), C.settlementId)).toBe(true);
  await info.attach('siege-defense', { body: JSON.stringify({ before, contestedSieges: contested.sieges, errors }, null, 2), contentType: 'application/json' });
  expect(errors).toEqual([]);
});
