import { expect, test, type Page, type TestInfo } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { deserializeGame, serializeGame, type GameState } from '@theandril/sim';
import { exportSave } from '@theandril/persistence';
import { characterCampaign, CHARACTER_FIXTURE as C } from '../../packages/test-fixtures/src/character-fixture';
import { closeCampaignOptions, closeManagement, openSelectedOrders, selectFromRegistry } from './ui-navigation';

async function importCampaign(page: Page, state: GameState) {
  await page.locator('input[type=file]').setInputFiles({ name: 'hermes-ui-slice.theandril', mimeType: 'application/gzip', buffer: Buffer.from(await exportSave(serializeGame(state))) });
  await expect(page.getByTestId('feedback')).toContainText('Imported campaign');
}
async function evidence(info: TestInfo, name: string, value: unknown) {
  await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
}

for (const definitionId of ['faction.ashen_compact', 'faction.reedbound_council']) {
  test(`R18 paid Waykeeper resolves shared art for ${definitionId}`, async ({ page }, info) => {
    const consoleMessages: string[] = [], errors: string[] = [], requests: string[] = [];
    page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') consoleMessages.push(message.text()); });
    page.on('pageerror', error => errors.push(error.message));
    page.on('request', request => { if (/\/art\/.*\.png/.test(request.url())) requests.push(new URL(request.url()).pathname); });
    // Authored funded/infrastructure fixture, not a natural campaign. Appointment,
    // attachment and all inspection below use public controls; no debug mutations.
    const game = characterCampaign();
    game.factions[0]!.definitionId = definitionId;
    game.settlements[C.homeId]!.buildings.push('building.archive');
    const validated = deserializeGame(serializeGame(game));
    const catalog = JSON.parse(await readFile('apps/web/public/art/catalog.json', 'utf8'));
    const asset = catalog.assets.find((item: { id: string }) => item.id === 'character.waykeeper');
    const atlas = catalog.atlases.find((item: { id: string }) => item.id === asset.atlasId);
    expect(atlas.width * atlas.height * 4).toBe(4 * 1024 * 1024);
    await page.goto('/'); await importCampaign(page, validated);
    await selectFromRegistry(page, 'settlements', C.homeName); await openSelectedOrders(page);
    await page.getByTestId('character-appointments').locator('summary').click();
    const before = await page.evaluate(() => window.__THEANDRIL__!.getSummary()!.treasury);
    await page.getByRole('button', { name: 'Appoint Waykeeper', exact: true }).click();
    await expect.poll(() => page.evaluate(() => window.__THEANDRIL__!.getSummary()!.characters.filter(item => item.definitionId === 'character.waykeeper').length)).toBe(1);
    expect(await page.evaluate(() => window.__THEANDRIL__!.getSummary()!.treasury)).toBe(before - 40);
    await page.getByRole('button', { name: 'Open character roster', exact: true }).click();
    const caster = await page.evaluate(() => window.__THEANDRIL__!.getSummary()!.characters.find(item => item.definitionId === 'character.waykeeper')!);
    const roster = page.getByRole('dialog', { name: 'Characters & agents', exact: true });
    await roster.getByRole('button', { name: `Inspect ${caster.name} (${caster.id})`, exact: true }).click();
    const art = roster.locator('[data-art-content-id="character.waykeeper"]');
    await expect(art).toHaveCount(2);
    for (const icon of await art.all()) {
      await expect(icon).toHaveAttribute('data-art-state', 'shared');
      await expect(icon).toHaveAttribute('data-art-rendered-id', 'character.waykeeper');
      await expect(icon).toHaveAccessibleName(/shared Waykeeper silhouette/);
      await expect(icon).not.toContainText('Generic');
    }
    await roster.screenshot({ path: info.outputPath('waykeeper-paid-desktop.png') });
    const hash = await page.evaluate(() => window.__THEANDRIL__!.getStateHash());
    await page.setViewportSize({ width: 390, height: 844 });
    await roster.getByRole('combobox', { name: 'Assign to army', exact: true }).selectOption(C.armyId);
    await roster.getByRole('button', { name: 'Assign character', exact: true }).click();
    await expect.poll(() => page.evaluate(id => window.__THEANDRIL__!.getSummary()!.characters.find(item => item.id === id)?.location, caster.id)).toEqual({ kind: 'army', armyId: C.armyId });
    expect(await page.evaluate(() => window.__THEANDRIL__!.getStateHash())).not.toBe(hash);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await roster.screenshot({ path: info.outputPath('waykeeper-assigned-390.png') });
    await roster.getByRole('button', { name: 'Close characters', exact: true }).click();
    await closeManagement(page); await closeCampaignOptions(page);
    await page.getByRole('button', { name: 'Characters & agents', exact: true }).click();
    await expect(roster.locator('[data-art-content-id="character.waykeeper"][data-art-state="shared"]').first()).toBeVisible();
    expect(requests.filter(url => url === atlas.imageUrl)).toHaveLength(1);
    const otherBattlePages = catalog.atlases.filter((item: { id: string }) => item.id.startsWith('battle') && item.id !== atlas.id);
    for (const other of otherBattlePages) expect(requests).not.toContain(other.imageUrl);
    expect(errors).toEqual([]);
    await evidence(info, 'waykeeper-evidence', { definitionId, caster, paidCoin: 40, atlas, requests, consoleMessages, errors });
  });
}
