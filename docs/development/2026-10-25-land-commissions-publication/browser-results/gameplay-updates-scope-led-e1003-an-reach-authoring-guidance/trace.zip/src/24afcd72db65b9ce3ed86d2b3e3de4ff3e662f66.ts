import { writeFile } from 'node:fs/promises';
import { expect, test } from '@playwright/test';

for (const dimensions of [{ width: 1440, height: 1000, scale: 100 }, { width: 1366, height: 768, scale: 100 }, { width: 390, height: 844, scale: 100 }, { width: 390, height: 844, scale: 130 }]) {
  test(`readable journal at ${dimensions.width}px and ${dimensions.scale}% text`, async ({ page }, testInfo) => {
    const errors: string[] = [];
    const workers: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('response', response => { if (response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
    page.on('worker', worker => workers.push(worker.url()));
    await page.setViewportSize({ width: dimensions.width, height: dimensions.height });
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('updates/dispatches/');
    await page.evaluate(scale => { document.documentElement.style.fontSize = `${scale}%`; }, dimensions.scale);
    await page.getByRole('heading', { name: 'Theandril Dispatches', exact: true }).waitFor();
    // Exercise real lazy loading by scrolling to each visible image before the full-page capture.
    for (const image of await page.locator('img:visible').all()) {
      await image.scrollIntoViewIfNeeded();
      await image.evaluate(element => (element as HTMLImageElement).decode());
    }
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: testInfo.outputPath('explore-top.png') });
    await page.screenshot({ path: testInfo.outputPath('explore-full.png'), fullPage: true });
    await expect(page.locator('figure > figcaption').first()).toHaveCSS('font-size', /./);
    expect(await page.locator('figure > figcaption').first().evaluate(element => parseFloat(getComputedStyle(element).fontSize))).toBeGreaterThanOrEqual(14);
    expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
    await page.getByRole('searchbox', { name: 'Search dispatches' }).fill('no-such-dispatch');
    await page.getByRole('heading', { name: 'No dispatches found' }).scrollIntoViewIfNeeded();
    await page.screenshot({ path: testInfo.outputPath('no-results.png') });
    await page.getByRole('button', { name: 'Reset search & filters', exact: true }).click();
    await page.getByRole('link', { name: 'Read the featured dispatch' }).click();
    await page.evaluate(scale => { document.documentElement.style.fontSize = `${scale}%`; }, dimensions.scale);
    await expect(page.getByRole('heading', { level: 1, name: 'Give land work a budget' })).toBeVisible();
    await page.screenshot({ path: testInfo.outputPath('reader-top.png') });
    for (const id of ['land-commission-summary']) {
      await page.locator(`.illustration-${id}`).scrollIntoViewIfNeeded();
      await page.locator(`.illustration-${id} > button > img`).evaluate(image => (image as HTMLImageElement).decode());
      await page.locator(`.illustration-${id}`).screenshot({ path: testInfo.outputPath(`${id}-illustration.png`) });
    }
    await page.getByRole('heading', { name: 'Watch two paid works complete' }).evaluate(element => element.scrollIntoView({ block: 'start' }));
    await page.screenshot({ path: testInfo.outputPath('reader-chapter.png') });
    expect(await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)).toBeLessThanOrEqual(1);
    const imageFacts = await page.locator('figure > button > img').evaluateAll(elements => elements.map(element => { const image = element as HTMLImageElement; return { src: image.currentSrc, width: image.naturalWidth, complete: image.complete }; }));
    expect(imageFacts.every(image => image.complete && image.width > 0)).toBe(true);
    expect(imageFacts.every(image => new URL(image.src).pathname.includes('/updates/'))).toBe(true);
    await writeFile(testInfo.outputPath('layout-evidence.json'), JSON.stringify({ dimensions, imageFacts, errors, workers }, null, 2));
    expect(errors).toEqual([]);
    expect(workers).toEqual([]);
  });
}

test('reading surfaces retain contrast without putting texture over the text', async ({ page }, testInfo) => {
  await page.goto('updates/dispatches/');
  await expect(page.getByRole('heading', { name: 'Theandril Dispatches', exact: true })).toBeVisible();
  const measurements = await page.evaluate(() => {
    const rgb = (value: string) => value.match(/[\d.]+/g)!.map(Number);
    const luminance = (color: number[]) => color.slice(0, 3).reduce((total, channel, index) => {
      const s = channel / 255;
      return total + (s <= .04045 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4) * [ .2126, .7152, .0722 ][index]!;
    }, 0);
    const ratio = (a: number[], b: number[]) => {
      const values = [luminance(a), luminance(b)].sort((x, y) => y - x);
      return (values[0]! + .05) / (values[1]! + .05);
    };
    return [
      ['.feature-summary', '.paper-content'], ['figure > figcaption', '.paper-content'],
      ['.scope-ledger dd', '.paper-content'], ['.contribution-note', '.contribute-section'],
      ['.plaque', '.plaque'], ['.site-header nav', '.journal-site'], ['.site-footer', '.journal-site'],
    ].map(([foregroundSelector, backgroundSelector]) => {
      const foreground = getComputedStyle(document.querySelector(foregroundSelector!)!).color;
      const background = getComputedStyle(document.querySelector(backgroundSelector!)!).backgroundColor;
      const fg = rgb(foreground), bg = rgb(background), alpha = bg[3] ?? 1;
      // Paper's translucent wash is bounded against black and white underneath.
      // Multiply-blended walnut cannot be brighter than its background color.
      const extremes = [0, 255].map(under => bg.slice(0, 3).map(channel => channel * alpha + under * (1 - alpha)));
      return { foregroundSelector, backgroundSelector, foreground, background, conservativeRatio: Math.min(...extremes.map(value => ratio(fg, value))) };
    });
  });
  await writeFile(testInfo.outputPath('contrast-evidence.json'), JSON.stringify(measurements, null, 2));
  for (const entry of measurements) expect(entry.conservativeRatio, entry.foregroundSelector).toBeGreaterThanOrEqual(4.5);
});

test('unknown dispatch links fail honestly and keyboard skip navigation works', async ({ page }) => {
  await page.goto('updates/dispatches/?dispatch=not-published');
  await expect(page.getByRole('heading', { name: 'That page is not in the journal' })).toBeVisible();
  await page.getByRole('link', { name: 'Browse published dispatches' }).click();
  await expect(page.getByRole('heading', { name: 'Theandril Dispatches', exact: true })).toBeVisible();
  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: 'Skip to content' })).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('main')).toBeFocused();
});

test('archive search combines topic filters, survives refresh and recovers from no results', async ({ page }) => {
  await page.goto('updates/dispatches/#archive');
  await page.getByRole('searchbox', { name: 'Search dispatches' }).fill('Vesper');
  await page.getByRole('button', { name: 'World & culture', exact: true }).click();
  await expect(page.getByRole('status')).toHaveText('1 dispatch');
  await expect(page.locator('.dispatch-row')).toHaveCount(1);
  await page.reload();
  await expect(page.getByRole('searchbox', { name: 'Search dispatches' })).toHaveValue('Vesper');
  await page.getByRole('button', { name: 'Engineering', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'No dispatches found' })).toBeVisible();
  await page.getByRole('button', { name: 'Reset search & filters', exact: true }).click();
  await expect(page.getByRole('status')).toHaveText('22 dispatches');
  await expect(page.locator('.dispatch-row')).toHaveCount(22);
});

test('scope ledger links real gates and a contributor can reach authoring guidance', async ({ page }) => {
  await page.goto('updates/dispatches/');
  await expect(page.getByRole('heading', { name: 'Road to 1.0', exact: true })).toBeVisible();
  const ledger = page.getByRole('region', { name: 'Road to 1.0' });
  await expect(ledger.getByText('Accepted scope', { exact: true })).toBeVisible();
  await expect(ledger.getByText('Current / partial', { exact: true }).first()).toBeVisible();
  await expect(ledger.getByText('Proposal / deferred', { exact: true })).toBeVisible();
  await expect(ledger.getByText('Not this update', { exact: true })).toBeVisible();
  await expect(ledger).toContainText('player travel never resumes itself');
  await expect(ledger).toContainText('2,432');
  await expect(page.getByRole('link', { name: 'Definition of done', exact: true })).toHaveAttribute('href', /DEFINITION_OF_DONE.md$/);
  await expect(page.getByRole('heading', { name: 'The reference shelf' })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Authoring guide', exact: true })).toHaveAttribute('href', /docs\/updates\/CONTRIBUTING.md$/);
  await expect(page.getByRole('link', { name: 'Dispatch template', exact: true })).toHaveAttribute('href', /docs\/updates\/TEMPLATE.md$/);
});

test('a keyboard reader can enlarge a real image and return to the same control', async ({ page }) => {
  await page.goto('updates/dispatches/?dispatch=twenty-four-cultures');
  const trigger = page.getByRole('button', { name: 'Enlarge cultures image', exact: true });
  await expect(trigger).toBeVisible();
  await trigger.focus();
  await page.keyboard.press('Enter');
  const dialog = page.getByRole('dialog', { name: 'Image detail' });
  await expect(dialog).toBeVisible();
  await expect(dialog.getByRole('img')).toHaveJSProperty('naturalWidth', 900);
  await expect(dialog.getByRole('button', { name: 'Close image', exact: true })).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(dialog).not.toBeVisible();
  await expect(trigger).toBeFocused();
});

// Resolves under either the normal root server or the Pages-base journal harness.
test('public journal opens a permanent, refresh-safe campaign dispatch', async ({ page }) => {
  await page.goto('updates/dispatches/');
  await expect(page.getByRole('heading', { name: 'Theandril Dispatches', exact: true })).toBeVisible();
  await page.getByRole('link', { name: 'Read the featured dispatch' }).click();
  await expect(page).toHaveURL(/updates\/dispatches\/\?dispatch=land-commissions$/);
  await expect(page.getByRole('heading', { level: 1, name: 'Give land work a budget' })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('heading', { level: 1, name: 'Give land work a budget' })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Land commission verification' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/24a710aaa8ddc49aa4ce56173ac043fe4ba1f767/docs/development/2026-10-25-land-commissions/README.md');
  await page.getByRole('link', { name: 'Keep growing hearths at work', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Worker stewardship verification' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/97b248ed596c931f01d0df66d60fcf25f819eaef/docs/development/2026-10-25-worker-stewardship/README.md');
  await page.getByRole('link', { name: 'Give the order, then review each result', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Posting and charter intent checks' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/670a18af843f95c80198a255e1894a708c5f1391/docs/development/2026-10-25-group-intent/README.md');
  await page.getByRole('link', { name: 'Find empty queues and waiting charters', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Settlement order implementation and acceptance' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/5da6b62e9d9522d973f87b0c7022ada370636dcc/docs/development/2026-10-25-settlement-order-filters/README.md');
  await page.getByRole('link', { name: 'Change patrol policies across the checked companies', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Group patrol implementation and acceptance' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/8d880eb60cdca549d5ff1086ef95e095e81feea5/docs/development/2026-10-24-group-patrols/README.md');
  await page.getByRole('link', { name: 'Find waiting orders in a crowded roster', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Registry implementation and acceptance' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/da12978fb596a73a7fddcfb8e914efb7924efbc2/docs/development/2026-10-24-army-order-filters/README.md');
  await page.getByRole('link', { name: 'Before peace decides the race', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Counterplay implementation and retained evidence' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/bff98894992762e797daf2aa63b487b4a98c0f28/docs/development/2026-10-24-project-counterplay/README.md');
  await page.getByRole('link', { name: 'When a home patrol loses its hearth', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Retirement implementation and retained evidence' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/68ef5fa7e524a3cd4e7e60fd7bbdd9037a6bc120/docs/development/2026-10-24-patrol-retirement/README.md');
  await page.getByRole('link', { name: 'Keep the watch moving', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Recovery evidence and retained failures' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/dee74cf9c4e2d153f9c5f5cfdbd9221798205481/docs/development/2026-10-24-patrol-recovery/README.md');
  await page.getByRole('link', { name: 'Hold the frontier, provision the crossing', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Implementation and retained failures' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/f33a816f3a853229695b902af007e4e3f3547275/docs/development/2026-09-27-reinforcement-logistics/README.md');
  await page.getByRole('link', { name: 'A voyage needs stores for the way home', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Factual evidence review' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/b623c2c91d4d852cba710f2d996c28a6b1b5d624/docs/development/2026-09-23-fleet-provisions/factual-review.md');
  await page.getByRole('link', { name: 'A campaign worth keeping', exact: true }).click();
  await expect(page.getByRole('heading', { level: 1, name: 'A campaign worth keeping' })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Post-fix review reconciliation' })).toHaveAttribute('href', 'https://github.com/ErikBurdett/Theandril/blob/8b3b8c148b7e8ee3689001210033fee7a1b8a6ef/docs/development/post-fix-review/summary.json');
  await page.getByRole('link', { name: 'All dispatches', exact: true }).click();
  await expect(page).toHaveURL(/updates\/dispatches\/#archive$/);
  await expect(page.getByRole('heading', { name: 'Theandril Dispatches', exact: true })).toBeVisible();
  // Searching must keep the reader on the dispatches page, not send them to the site home.
  await page.getByRole('searchbox', { name: 'Search dispatches' }).fill('archive');
  await expect(page).toHaveURL(/updates\/dispatches\/\?q=archive#archive$/);
  await expect(page.getByRole('navigation', { name: 'Main navigation' }).getByRole('link', { name: 'Dispatches' })).toHaveAttribute('aria-current', 'page');
});
